/*
==========================================
    Name: Md. Shemon Mia 
    ID: 42250303017
    Section: E
    Date: 08-11-2025
==========================================
*/

#include <stdio.h>
int main() {
    int num, i;

    printf("Enter a number to display its multiplication table: ");
    scanf("%d", &num);

    printf("Multiplication Table of %d:\n", num);
    for(i = 1 ; i<=10; i++){
        printf("%d x %d = %d\n",num,i ,num*i);
    }

    return 0;
}
