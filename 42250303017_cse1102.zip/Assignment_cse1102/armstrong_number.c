/*
==========================================
    Name: Md. Shemon Mia 
    ID: 42250303017
    Section: E
    Date: 07-11-2025
==========================================
*/

#include <stdio.h>
int main(){
    int num,originalNum, remainder,result = 0;
    printf("Enter A Number: ");
    scanf("%d",&num);  
    originalNum = num;

    while (num != 0)
    {
        remainder = num % 10;
        result += remainder * remainder * remainder;
        num = num / 10;

    }

    if (result == originalNum){
        printf("%d is an Armstrong number.\n", originalNum);
    }else{
        printf("%d is not an Armstrong number.\n", originalNum);
    }
        return 0;
    
}