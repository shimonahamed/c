
/*
==========================================
    Name: Md. Shemon Mia 
    ID: 42250303017
    Section: E
    Date: 09-11-2025
==========================================
*/
#include <stdio.h>

int main(void) {
    int n;
    unsigned long long factorial = 1; 

    printf("Enter a number: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Factorial does not exist for negative numbers.\n");
    } else {
        for (int i = 1; i <= n; i++) {
            factorial *= i; 
        }
        printf("Factorial of %d = %llu\n", n, factorial);
    }

    return 0;
}
