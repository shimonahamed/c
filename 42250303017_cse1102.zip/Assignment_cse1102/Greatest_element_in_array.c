
/*
==========================================
    Name: Md. Shemon Mia 
    ID: 42250303017
    Section: E
    Date: 08-11-2025
==========================================
*/

int main(void){
   int arr_size;
    printf("Enter The Size Of The Array: ");
    scanf("%d", &arr_size);

    int arr[arr_size];
    printf("Enter %d Elements: ", arr_size);
    for(int i = 0; i< arr_size; i++){
        scanf("%d", &arr[i]);
    }
    
    printf("\nOriginal Array: ");
    for(int i = 0; i < arr_size; i++){
        printf("%d ", arr[i]);  
    }
    int largest = arr[0];

    for (int i = 1; i < arr_size; i++)
    {
        if (arr[i] > largest) {
            largest = arr[i];
        }
    }
    
    printf("\n Greatest Element: %d",largest);

    return 0;
}