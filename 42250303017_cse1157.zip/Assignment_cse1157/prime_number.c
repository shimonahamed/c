
/*
==========================================
    Name: Md. Shemon Mia 
    ID: 42250303017
    Section: E
    Date: 11-11-2025
==========================================
*/
#include <stdio.h>

int main(void) {
    int start, end;
            int count = 0;

    printf("Enter Starting Number: ");
    scanf("%d", &start);

    printf("Enter Ending Number: ");
    scanf("%d", &end);
    for (int i = start; i <= end; i++) {
        int isPrime = 1; 

        if (i <= 1) {
            isPrime = 0; 
        } else {
            for (int j = 2; j <= i / 2; j++) {
                if (i % j == 0) {
                    isPrime = 0; 
                    break;
                }
            }
        }

        if (isPrime == 1){
            printf("%d is a prime number.\n", i);
            count +=i;

        }
        else
            printf("%d is not a prime number.\n", i);
    }
     printf("\nSum of all prime numbers = %d\n", count);

    return 0;
}
