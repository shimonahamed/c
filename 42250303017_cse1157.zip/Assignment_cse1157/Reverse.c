/*
==========================================
    Name: Md. Shemon Mia 
    ID: 42250303017
    Section: E
    Date: 12-11-2025
==========================================
*/





#include <stdio.h>
int main(void){
    int num;
    printf("Enter The Number Of Elements: ");
    scanf("%d",&num);
    int arr[num];
    printf("Enter %d Elements: ",num);
   for(int i = 0 ; i < num ; i++){
    scanf("%d",&arr[i]);
   }

   printf("\nOriginal Array: ");
    for(int i = 0 ; i < num ; i++){
        printf("%d ",arr[i]);  
    }
    printf("\nReversed Array: ");
    for(int i = num -1 ; i >= 0 ; i--){
        printf("%d ",arr[i]);  

    }
    
}
