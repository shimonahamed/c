/*
Name: Mst. Mim Akter
ID: 42250303018
section: E
Date: 30-12-2025
*/




#include <stdio.h>

    int main() {
        int num,i;

        printf("Enter number of students:");
        scanf("%d", &num);

        struct {
            char name[50];
            int marks;
        } student[num];

        for ( i = 0; i < num; i++) {
            printf("\nEnter details for student %d\n", i + 1);
            printf("Name: ");
            scanf("%s", &student[i].name);
            printf("Marks: ");
            scanf("%d", &student[i].marks);
        }

        int max = 0;
        for (i = 1; i < num; i++) {
            if (student[i].marks > student[max].marks) {
                max = i;
            }
        }

        printf("\nStudent with highest marks:\n");

        printf("Name: %s\n", student[max].name);

        printf("Marks: %d\n", student[max].marks);

        return 0;
    }
