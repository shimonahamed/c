/*
Name: Mst. Mim Akter
ID: 42250303018
section: E
Date: 30-12-2025
*/



#include <stdio.h>
    int main() {
        int num, i;

        printf("Enter number of employees:");

        scanf("%d", &num);

        struct {
                int id;
                char name[50];
                float salary;
            } employee[num];

        for (i = 0; i < num; i++) {
            printf("\nEnter employee %d ID:", i + 1);
            scanf("%d", &employee[i].id);
            printf("Enter employee %d name:", i + 1);
            scanf("%s", employee[i].name);
            printf("Enter employee %d salary:", i + 1);
            scanf("%f", &employee[i].salary);
        }

        printf("\nEmployee Details:\n");

        for (i = 0; i < num; i++) {
            printf("ID: %d, Name: %s, Salary: %.2f\n",

            employee[i].id, employee[i].name, employee[i].salary);
        }


        return 0;
    }
